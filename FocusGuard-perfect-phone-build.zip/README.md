# FocusGuard

A native Kotlin Android accessibility-service app that helps reduce Instagram distraction.

## Features
- Covers Instagram Reels when the Reels player is detected.
- Covers the Explore grid while leaving the search box usable for people search.
- Covers the Reels tab button.
- Shows rotating focus messages.
- Light/dark palette follows system night mode; Battery Saver also selects the dark palette.
- Reels screen includes a Back to Home button.
- Uses an AccessibilityService overlay; accessibility permission must be enabled by the user.

## Important
Instagram changes internal view IDs between releases. The app uses IDs known to the original implementation; if Instagram changes them, blocking may need an update.

## Build
Open the project in Android Studio or use a compatible Gradle/Android SDK environment. The GitHub Actions workflow builds a debug APK and publishes it as an artifact.
